<?php
/**
 * @package butler
 */
class ButlerLog extends xPDOSimpleObject {}
?>