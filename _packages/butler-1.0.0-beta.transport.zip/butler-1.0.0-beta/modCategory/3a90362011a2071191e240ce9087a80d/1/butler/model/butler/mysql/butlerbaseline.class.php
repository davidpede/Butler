<?php
/**
 * @package butler
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/butlerbaseline.class.php');
class ButlerBaseline_mysql extends ButlerBaseline {}
?>