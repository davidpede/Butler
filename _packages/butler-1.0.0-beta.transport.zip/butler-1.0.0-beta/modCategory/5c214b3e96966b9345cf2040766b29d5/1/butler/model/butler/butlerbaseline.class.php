<?php
/**
 * @package butler
 */
class ButlerBaseline extends xPDOSimpleObject {}
?>