<?php
/**
 * @package butler
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/butlertasks.class.php');
class ButlerTasks_mysql extends ButlerTasks {}
?>