<?php
/**
 * @package butler
 */
class ButlerTasks extends xPDOSimpleObject {}
?>