<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'ButlerAlerts',
    1 => 'ButlerBaseline',
    2 => 'ButlerLog',
    3 => 'ButlerRunlog',
    4 => 'ButlerScanlog',
    5 => 'ButlerTasks',
  ),
);