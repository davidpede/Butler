<?php
/**
 * @package butler
 */
class ButlerScanlog extends xPDOSimpleObject {}
?>