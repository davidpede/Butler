<?php
/**
 * @package butler
 */
class ButlerRunlog extends xPDOSimpleObject {}
?>