<?php
/**
 * @package butler
 */
class ButlerAlerts extends xPDOSimpleObject {}
?>