--------------------
Extra: Butler
--------------------
Version: 1.0.0-beta
Released: N/A
Since: July 24, 2017
Author: David Pede <d.pede@prp-co.uk>
Copyright: (C) 2017 PRP Architects LLP. All rights reserved. <brand@prp-co.uk>

A task scheduling and notification Extra for MODX Revolution.

Official Documentation:
http://rtfm.modx.com/extras/revo/butler

GitHub Repository:
http://github.com/tasianmedia/butler

Bugs & Feature Requests:
http://github.com/tasianmedia/butler/issues

License:
Released under the GNU General Public License; either version 2 of the License, or (at your option) any later version. http://www.gnu.org/licenses/gpl.html